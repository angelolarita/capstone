<nav class="navbar navbar-expand-lg fixed-top" style="background-color: #1d8348; width: 100%;">
    <div class="container-fluid">
        <a class="navbar-brand d-flex align-items-center text-white" href="#">
            <img src="Assets/icon/actscc_logo.png" width="50" height="50" class="d-inline-block align-top" alt="Logo"
                style="margin-right: 10px;">
            <span id="alumniText" class="ml-2"
                style="font-family: 'Arial', sans-serif; font-weight: bold; color: white; margin-left: 10px;">
                ACTS COMPUTER COLLEGE
            </span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link text-white" href="../caps/landingpage.php">HOME</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="#">ABOUT</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="#">ACADEMICS</a></li>
                <!-- <li class="nav-item"><a class="nav-link text-white" href="#">STUDENTS</a></li> -->
                <!-- <li class="nav-item"><a class="nav-link text-white" href="#">RESEARCH</a></li> -->
                <li class="nav-item"><a class="nav-link text-white" href="#">ALUMNI</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="#">Profile</a></li>
            </ul>
        </div>
    </div>
</nav>


<div class="p-4 border rounded shadow-sm bg-white">
    <div class="block-heading text-center">
        <h2 class="text-info">Graduate Tracer Survey</h2>
    </div>

    <h3 class="mb-4">A. General Information</h3>

    <form action="#" method="get">
        <div class="form-group">
            <label>Student No.</label>
            <input class="form-control" type="text" name="student_no" required>
        </div>

        <div class="form-group row">
            <div class="col-md-4">
                <label>Last Name</label>
                <input class="form-control" type="text" name="last_name" required>
            </div>
            <div class="col-md-4">
                <label>First Name</label>
                <input class="form-control" type="text" name="first_name" required>
            </div>
            <div class="col-md-4">
                <label>Middle Name</label>
                <input class="form-control" type="text" name="middle_name">
            </div>
        </div>

        <div class="form-group">
            <label>Permanent Address</label>
            <input class="form-control" type="text" name="address" required>
        </div>

        <div class="form-group row">
            <div class="col-md-6">
                <label>Mobile No.</label>
                <input class="form-control" type="text" name="mobile">
            </div>
            <div class="col-md-6">
                <label>Email</label>
                <input class="form-control" type="email" name="email">
            </div>
        </div>

        <div class="form-group row">
            <div class="col-md-6">
                <label>Civil Status</label>
                <select class="form-control" name="civilstatus" required>
                    <option value="">Select</option>
                    <option value="Single">Single</option>
                    <option value="Married">Married</option>
                </select>
            </div>
            <div class="col-md-6">
                <label>Gender</label>
                <select class="form-control" name="gender" required>
                    <option value="">Select</option>
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                </select>
            </div>
        </div>

        <!-- Country Dropdown -->
        <div class="form-group">
            <label for="country">Country</label>
            <select class="form-control" id="country" name="country" required>
                <option value="">Select Country</option>
                <option value="Philippines">Philippines</option>
                <option value="United States">United States</option>
                <option value="Canada">Canada</option>
                <option value="Australia">Australia</option>
            </select>
        </div>

        <!-- Container for Philippine-specific location fields -->
        <div id="philippineLocation">
            <!-- Region Dropdown -->
            <div class="form-group">
                <label for="region">Region</label>
                <select class="form-control" id="region" name="region" required>
                    <option value="">Select Region</option>
                    <option value="Region 1">Region I - Ilocos Region</option>
                    <option value="Region 2">Region II - Cagayan Valley</option>
                    <option value="Region 3">Region III - Central Luzon</option>
                    <option value="Region 4-A">Region IV-A - CALABARZON</option>
                    <option value="Region 4-B">Region IV-B - MIMAROPA</option>
                    <option value="Region 5">Region V - Bicol Region</option>
                    <option value="CAR">CAR - Cordillera Administrative Region</option>
                    <option value="NCR">NCR - National Capital Region</option>
                    <option value="Region 6">Region VI - Western Visayas</option>
                    <option value="Region 7">Region VII - Central Visayas</option>
                    <option value="Region 8">Region VIII - Eastern Visayas</option>
                    <option value="Region 9">Region IX - Zamboanga Peninsula</option>
                    <option value="Region 10">Region X - Northern Mindanao</option>
                    <option value="Region 11">Region XI - Davao Region</option>
                    <option value="Region 12">Region XII - SOCCSKSARGEN</option>
                    <option value="Region 13">Region XIII - Caraga Region</option>
                    <option value="BARMM">BARMM - Bangsamoro Autonomous Region in Muslim Mindanao</option>
                </select>
            </div>

            <!-- Province Dropdown -->
            <div class="form-group">
                <label for="province">Province</label>
                <select class="form-control" id="province" name="province" required>
                    <option value="">Select Province</option>
                </select>
            </div>

            <!-- City/Municipality Dropdown -->
            <div class="form-group">
                <label for="city_bayan">City / Municipality</label>
                <select class="form-control" id="city_bayan" name="city_bayan" required>
                    <option value="">Select City or Municipality</option>
                </select>
            </div>

            <!-- Barangay Dropdown -->
            <div class="form-group">
                <label for="barangay">Barangay</label>
                <select class="form-control" id="barangay" name="barangay" required>
                    <option value="">Select Barangay</option>
                </select>
            </div>
        </div>

        <div class="text-right mt-4">
            <a class="btn btn-primary" href="../caps/educationbackground.php" role="button">Next</a>
        </div>
</div>
</form>
</div>