<?php

// Define constants for database configuration
define('DB_NAME', 'capstone');
define('DB_PASSWORD', '');
define('DB_USER', 'root');
define('DB_HOST', 'localhost');  // Assuming you're using localhost
define('ROOT_FOLDER', $_SERVER['DOCUMENT_ROOT'] . '/capstone');