document.addEventListener('DOMContentLoaded', function() {
      // Dummy data for Philippine regions
      const regionsData = {
        "Region 1": {
          provinces: ["Ilocos Norte", "Ilocos Sur", "La Union", "Pangasinan"],
          cities: {
            "Ilocos Norte": ["Laoag City", "Batac City"],
            "Ilocos Sur": ["Vigan City", "Candon City"],
            "La Union": ["San Fernando City", "Agoo"],
            "Pangasinan": ["Dagupan", "San Carlos"]
          },
          barangays: {
            "Laoag City": ["Barangay 1", "Barangay 2"],
            "Batac City": ["Barangay 3", "Barangay 4"],
            "Vigan City": ["Barangay 5", "Barangay 6"],
            "Candon City": ["Barangay 7", "Barangay 8"],
            "San Fernando City": ["Barangay 9", "Barangay 10"],
            "Agoo": ["Barangay 11", "Barangay 12"],
            "Dagupan": ["Barangay 13", "Barangay 14"],
            "San Carlos": ["Barangay 15", "Barangay 16"]
          }
        },
        "Region 2": {
          provinces: ["Batanes", "Cagayan", "Isabela", "Nueva Vizcaya", "Quirino"],
          cities: {
            "Batanes": ["Basco"],
            "Cagayan": ["Tuguegarao"],
            "Isabela": ["Ilagan"],
            "Nueva Vizcaya": ["Bayombong"],
            "Quirino": ["Cabarroguis"]
          },
          barangays: {
            "Basco": ["Barangay A", "Barangay B"],
            "Tuguegarao": ["Barangay C", "Barangay D"],
            "Ilagan": ["Barangay E", "Barangay F"],
            "Bayombong": ["Barangay G", "Barangay H"],
            "Cabarroguis": ["Barangay I", "Barangay J"]
          }
        },
        "Region 3": {
          provinces: ["Aurora", "Bataan", "Bulacan", "Cavite", "Laguna", "Batangas", "Quezon", "Rizal"],
          cities: {
            "Aurora": ["Baler"],
            "Bataan": ["Balanga"],
            "Bulacan": ["Malolos"],
            "Cavite": ["Dasmariñas"],
            "Laguna": ["Calamba"],
            "Batangas": ["Batangas City"],
            "Quezon": ["Lucena"],
            "Rizal": ["Antipolo"]
          },
          barangays: {
            "Baler": ["Barangay 1", "Barangay 2"],
            "Balanga": ["Barangay 3", "Barangay 4"],
            "Malolos": ["Barangay 5", "Barangay 6"],
            "Dasmariñas": ["Barangay 7", "Barangay 8"],
            "Calamba": ["Barangay 9", "Barangay 10"],
            "Batangas City": ["Barangay 11", "Barangay 12"],
            "Lucena": ["Barangay 13", "Barangay 14"],
            "Antipolo": ["Barangay 15", "Barangay 16"]
          }
        },
        "Region 4-A": {
          provinces: ["Cavite", "Laguna", "Batangas", "Quezon", "Rizal"],
          cities: {
            "Cavite": ["Imus", "Tagaytay"],
            "Laguna": ["Santa Rosa"],
            "Batangas": ["Lipa"],
            "Quezon": ["Tanauan"],
            "Rizal": ["San Mateo"]
          },
          barangays: {
            "Imus": ["Barangay A1", "Barangay A2"],
            "Tagaytay": ["Barangay A3", "Barangay A4"],
            "Santa Rosa": ["Barangay A5", "Barangay A6"],
            "Lipa": ["Barangay A7", "Barangay A8"],
            "Tanauan": ["Barangay A9", "Barangay A10"],
            "San Mateo": ["Barangay A11", "Barangay A12"]
          }
        },
        "Region 4-B": {
          provinces: ["Mindoro Occidental", "Mindoro Oriental", "Marinduque", "Romblon", "Palawan"],
          cities: {
            "Mindoro Occidental": ["Calapan"],
            "Mindoro Oriental": ["Puerto Galera"],
            "Marinduque": ["Boac"],
            "Romblon": ["Odiongan"],
            "Palawan": ["Puerto Princesa"]
          },
          barangays: {
            "Calapan": ["Barangay B1", "Barangay B2"],
            "Puerto Galera": ["Barangay B3", "Barangay B4"],
            "Boac": ["Barangay B5", "Barangay B6"],
            "Odiongan": ["Barangay B7", "Barangay B8"],
            "Puerto Princesa": ["Barangay B9", "Barangay B10"]
          }
        },
        "Region 5": {
          provinces: ["Albay", "Camarines Norte", "Camarines Sur", "Catanduanes", "Masbate", "Sorsogon"],
          cities: {
            "Albay": ["Legazpi"],
            "Camarines Norte": ["Daet"],
            "Camarines Sur": ["Naga"],
            "Catanduanes": ["Virac"],
            "Masbate": ["Masbate City"],
            "Sorsogon": ["Sorsogon City"]
          },
          barangays: {
            "Legazpi": ["Barangay C1", "Barangay C2"],
            "Daet": ["Barangay C3", "Barangay C4"],
            "Naga": ["Barangay C5", "Barangay C6"],
            "Virac": ["Barangay C7", "Barangay C8"],
            "Masbate City": ["Barangay C9", "Barangay C10"],
            "Sorsogon City": ["Barangay C11", "Barangay C12"]
          }
        },
        "CAR": {
          provinces: ["Abra", "Apayao", "Benguet", "Ifugao", "Kalinga", "Mountain Province"],
          cities: {
            "Abra": ["Bangued"],
            "Apayao": ["Kabugao"],
            "Benguet": ["La Trinidad"],
            "Ifugao": ["Lagawe"],
            "Kalinga": ["Tabuk"],
            "Mountain Province": ["Bontoc"]
          },
          barangays: {
            "Bangued": ["Barangay D1", "Barangay D2"],
            "Kabugao": ["Barangay D3", "Barangay D4"],
            "La Trinidad": ["Barangay D5", "Barangay D6"],
            "Lagawe": ["Barangay D7", "Barangay D8"],
            "Tabuk": ["Barangay D9", "Barangay D10"],
            "Bontoc": ["Barangay D11", "Barangay D12"]
          }
        },
        "NCR": {
          provinces: ["Metro Manila"],
          cities: {
            "Metro Manila": ["Manila", "Quezon City"]
          },
          barangays: {
            "Manila": ["Barangay E1", "Barangay E2"],
            "Quezon City": ["Barangay E3", "Barangay E4"]
          }
        },
        "Region 6": {
          provinces: ["Aklan", "Antique", "Capiz", "Iloilo", "Negros Occidental"],
          cities: {
            "Aklan": ["Kalibo"],
            "Antique": ["San Jose"],
            "Capiz": ["Roxas City"],
            "Iloilo": ["Iloilo City"],
            "Negros Occidental": ["Bacolod"]
          },
          barangays: {
            "Kalibo": ["Barangay F1", "Barangay F2"],
            "San Jose": ["Barangay F3", "Barangay F4"],
            "Roxas City": ["Barangay F5", "Barangay F6"],
            "Iloilo City": ["Barangay F7", "Barangay F8"],
            "Bacolod": ["Barangay F9", "Barangay F10"]
          }
        },
        "Region 7": {
          provinces: ["Bohol", "Cebu", "Negros Oriental", "Siquijor"],
          cities: {
            "Bohol": ["Tagbilaran"],
            "Cebu": ["Cebu City"],
            "Negros Oriental": ["Dumaguete"],
            "Siquijor": ["Siquijor"]
          },
          barangays: {
            "Tagbilaran": ["Barangay G1", "Barangay G2"],
            "Cebu City": ["Barangay G3", "Barangay G4"],
            "Dumaguete": ["Barangay G5", "Barangay G6"],
            "Siquijor": ["Barangay G7", "Barangay G8"]
          }
        },
        "Region 8": {
          provinces: ["Biliran", "Eastern Samar", "Leyte", "Northern Samar", "Samar", "Southern Leyte"],
          cities: {
            "Biliran": ["Naval"],
            "Eastern Samar": ["Borongan"],
            "Leyte": ["Tacloban"],
            "Northern Samar": ["Catubig"],
            "Samar": ["Calbayog"],
            "Southern Leyte": ["Maasin"]
          },
          barangays: {
            "Naval": ["Barangay H1", "Barangay H2"],
            "Borongan": ["Barangay H3", "Barangay H4"],
            "Tacloban": ["Barangay H5", "Barangay H6"],
            "Catubig": ["Barangay H7", "Barangay H8"],
            "Calbayog": ["Barangay H9", "Barangay H10"],
            "Maasin": ["Barangay H11", "Barangay H12"]
          }
        },
        "Region 9": {
          provinces: ["Zamboanga del Norte", "Zamboanga del Sur", "Zamboanga Sibugay"],
          cities: {
            "Zamboanga del Norte": ["Dipolog"],
            "Zamboanga del Sur": ["Pagadian"],
            "Zamboanga Sibugay": ["Ipil"]
          },
          barangays: {
            "Dipolog": ["Barangay I1", "Barangay I2"],
            "Pagadian": ["Barangay I3", "Barangay I4"],
            "Ipil": ["Barangay I5", "Barangay I6"]
          }
        },
        "Region 10": {
          provinces: ["Bukidnon", "Camiguin", "Lanao del Norte", "Misamis Occidental", "Misamis Oriental"],
          cities: {
            "Bukidnon": ["Malaybalay"],
            "Camiguin": ["Mambajao"],
            "Lanao del Norte": ["Iligan"],
            "Misamis Occidental": ["Oroquieta"],
            "Misamis Oriental": ["Cagayan de Oro"]
          },
          barangays: {
            "Malaybalay": ["Barangay J1", "Barangay J2"],
            "Mambajao": ["Barangay J3", "Barangay J4"],
            "Iligan": ["Barangay J5", "Barangay J6"],
            "Oroquieta": ["Barangay J7", "Barangay J8"],
            "Cagayan de Oro": ["Barangay J9", "Barangay J10"]
          }
        },
        "Region 11": {
          provinces: ["Davao de Oro", "Davao del Norte", "Davao del Sur", "Davao Oriental", "Davao Occidental"],
          cities: {
            "Davao de Oro": ["Tagum"],
            "Davao del Norte": ["Panabo"],
            "Davao del Sur": ["Digos"],
            "Davao Oriental": ["Manay"],
            "Davao Occidental": ["Malita"]
          },
          barangays: {
            "Tagum": ["Barangay K1", "Barangay K2"],
            "Panabo": ["Barangay K3", "Barangay K4"],
            "Digos": ["Barangay K5", "Barangay K6"],
            "Manay": ["Barangay K7", "Barangay K8"],
            "Malita": ["Barangay K9", "Barangay K10"]
          }
        },
        "Region 12": {
          provinces: ["Cotabato", "Sarangani", "South Cotabato", "Sultan Kudarat", "North Cotabato"],
          cities: {
            "Cotabato": ["Kidapawan"],
            "Sarangani": ["Malita"],
            "South Cotabato": ["Koronadal"],
            "Sultan Kudarat": ["Tacurong"],
            "North Cotabato": ["Libungan"]
          },
          barangays: {
            "Kidapawan": ["Barangay L1", "Barangay L2"],
            "Malita": ["Barangay L3", "Barangay L4"],
            "Koronadal": ["Barangay L5", "Barangay L6"],
            "Tacurong": ["Barangay L7", "Barangay L8"],
            "Libungan": ["Barangay L9", "Barangay L10"]
          }
        },
        "Region 13": {
          provinces: ["Agusan del Norte", "Agusan del Sur", "Surigao del Norte", "Surigao del Sur"],
          cities: {
            "Agusan del Norte": ["Butuan"],
            "Agusan del Sur": ["Bayugan"],
            "Surigao del Norte": ["Surigao City"],
            "Surigao del Sur": ["Bislig"]
          },
          barangays: {
            "Butuan": ["Barangay M1", "Barangay M2"],
            "Bayugan": ["Barangay M3", "Barangay M4"],
            "Surigao City": ["Barangay M5", "Barangay M6"],
            "Bislig": ["Barangay M7", "Barangay M8"]
          }
        },
        "BARMM": {
          provinces: ["Basilan", "Lanao del Sur", "Maguindanao", "Sulu", "Tawi-Tawi"],
          cities: {
            "Basilan": ["Isabela City"],
            "Lanao del Sur": ["Marawi"],
            "Maguindanao": ["Buluan"],
            "Sulu": ["Jolo"],
            "Tawi-Tawi": ["Languyan"]
          },
          barangays: {
            "Isabela City": ["Barangay N1", "Barangay N2"],
            "Marawi": ["Barangay N3", "Barangay N4"],
            "Buluan": ["Barangay N5", "Barangay N6"],
            "Jolo": ["Barangay N7", "Barangay N8"],
            "Languyan": ["Barangay N9", "Barangay N10"]
          }
        }
      };

      // Function to reset (clear) the Philippine dropdowns
      function resetPhilippineDropdowns() {
        document.getElementById('region').selectedIndex = 0;
        document.getElementById('province').innerHTML = '<option value="">Select Province</option>';
        document.getElementById('city_bayan').innerHTML = '<option value="">Select City or Municipality</option>';
        document.getElementById('barangay').innerHTML = '<option value="">Select Barangay</option>';
      }

      // When a country is selected, show/hide Philippine location fields accordingly
      document.getElementById('country').addEventListener('change', function() {
        const country = this.value;
        const philippineLocationDiv = document.getElementById('philippineLocation');

        if (country === "Philippines") {
          // Show the Philippine location container
          philippineLocationDiv.style.display = 'block';
        } else {
          // Hide the container and reset the fields if a non-Philippine country is selected
          philippineLocationDiv.style.display = 'none';
          resetPhilippineDropdowns();
        }
      });

      // When a region is selected, populate the province dropdown
      document.getElementById('region').addEventListener('change', function() {
        const region = this.value;
        const provinceSelect = document.getElementById('province');
        provinceSelect.innerHTML = '<option value="">Select Province</option>';

        if (region && regionsData[region]) {
          regionsData[region].provinces.forEach(province => {
            const option = document.createElement('option');
            option.value = province;
            option.textContent = province;
            provinceSelect.appendChild(option);
          });
        }
        // Reset city and barangay dropdowns
        document.getElementById('city_bayan').innerHTML = '<option value="">Select City or Municipality</option>';
        document.getElementById('barangay').innerHTML = '<option value="">Select Barangay</option>';
      });

      // When a province is selected, populate the city/municipality dropdown
      document.getElementById('province').addEventListener('change', function() {
        const region = document.getElementById('region').value;
        const province = this.value;
        const citySelect = document.getElementById('city_bayan');
        citySelect.innerHTML = '<option value="">Select City or Municipality</option>';

        if (region && province && regionsData[region] && regionsData[region].cities[province]) {
          regionsData[region].cities[province].forEach(city => {
            const option = document.createElement('option');
            option.value = city;
            option.textContent = city;
            citySelect.appendChild(option);
          });
        }
        // Reset barangay dropdown
        document.getElementById('barangay').innerHTML = '<option value="">Select Barangay</option>';
      });

      // When a city is selected, populate the barangay dropdown
      document.getElementById('city_bayan').addEventListener('change', function() {
        const region = document.getElementById('region').value;
        const province = document.getElementById('province').value;
        const city = this.value;
        const barangaySelect = document.getElementById('barangay');
        barangaySelect.innerHTML = '<option value="">Select Barangay</option>';

        if (region && province && city && regionsData[region] && regionsData[region].barangays[city]) {
          regionsData[region].barangays[city].forEach(barangay => {
            const option = document.createElement('option');
            option.value = barangay;
            option.textContent = barangay;
            barangaySelect.appendChild(option);
          });
        }
      });
    });