<?php
// Include the database connection
require_once '../validate/graduate.php';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve submitted form data and trim whitespace
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name']);
    $last_name = trim($_POST['last_name']);
    $graduation_year = $_POST['graduation_year'];

    // Check if data is missing
    if (empty($first_name) || empty($middle_name) || empty($last_name) || empty($graduation_year)) {
        echo "Please fill in all fields.";
    } else {
        // Prepare the SQL query to validate the graduate
        $sql = "SELECT * FROM graduates 
                WHERE first_name = ? AND middle_name = ? AND last_name = ? AND graduation_year = ?";
        
        // Prepare and bind parameters
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            die('Error preparing the statement: ' . $conn->error);
        }

        $stmt->bind_param("ssss", $first_name, $middle_name, $last_name, $graduation_year);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if a record exists
        if ($result->num_rows > 0) {
            echo "Validation successful: The user is a graduate of ACTS Computer College.";
            // Proceed with further processing (e.g., save data, redirect, etc.)
        } else {
            echo "Validation failed: The user is not a graduate of ACTS Computer College.";
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    }
} else {
    echo "Invalid request method.";
}
?>