<?php
include '../includes/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $pdo->beginTransaction(); 

        $stmt = $pdo->prepare("INSERT INTO educational_background (degree, college, year_graduated, honors) 
                               VALUES (:degree, :college, :year_graduated, :honors)");
        $stmt->execute([
            ':degree' => $_POST['degree'],
            ':college' => $_POST['college'],
            ':year_graduated' => $_POST['year'],
            ':honors' => $_POST['honors']
        ]);

        $date_taken = !empty($_POST['exam_date']) ? date("Y-m-d", strtotime($_POST['exam_date'])) : null;
        if (!empty($_POST['exam_name'])) {
            $stmtExam = $pdo->prepare("INSERT INTO professional_exams (name_of_exam, date_taken, rating) 
                                       VALUES (:name_of_exam, :date_taken, :rating)");
            $stmtExam->execute([
                ':name_of_exam' => $_POST['exam_name'],
                ':date_taken' => $date_taken, 
                ':rating' => $_POST['exam_rating']
            ]);
        }

        if (!empty($_POST['reason']) && is_array($_POST['reason'])) {
            $stmtReason = $pdo->prepare("INSERT INTO course_reasons (reason, category) VALUES (:reason, :category)");
            foreach ($_POST['reason'] as $key => $values) {
                if (is_array($values)) {
                    foreach ($values as $category) {
                        $stmtReason->execute([
                            ':reason' => $key,
                            ':category' => $category
                        ]);
                    }
                } else {
                    // Handle single values (in case it's not an array)
                    $stmtReason->execute([
                        ':reason' => $key,
                        ':category' => $values
                    ]);
                }
            }
        }

        $pdo->commit();

        // Success message with redirect
        echo "<script>
                alert('Data submitted successfully!');
                window.location.href = 'http://localhost/caps/training.php';
              </script>";
        exit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        echo "<script>
                alert('Error: " . addslashes($e->getMessage()) . "');
                window.history.back();
              </script>";
        exit();
    }
} else {
    echo "<script>
            alert('Invalid request.');
            window.history.back();
          </script>";
    exit();
}
?>