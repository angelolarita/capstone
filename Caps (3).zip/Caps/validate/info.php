<?php
include '../includes/config.php';

$type = $_POST['type']; // Get the type of location (regions, provinces, etc.)

switch ($type) {
    case 'regions':
        $query = "SELECT region_id, region_name FROM regions";
        $result = mysqli_query($conn, $query);
        $regions = mysqli_fetch_all($result, MYSQLI_ASSOC);
        echo json_encode($regions);
        break;

    case 'provinces':
        $region_id = $_POST['region_id'];
        $query = "SELECT province_id, province_name FROM provinces WHERE region_id = '$region_id'";
        $result = mysqli_query($conn, $query);
        $provinces = mysqli_fetch_all($result, MYSQLI_ASSOC);
        echo json_encode($provinces);
        break;

    case 'cities':
        $province_id = $_POST['province_id'];
        $query = "SELECT city_id, city_name FROM cities WHERE province_id = '$province_id'";
        $result = mysqli_query($conn, $query);
        $cities = mysqli_fetch_all($result, MYSQLI_ASSOC);
        echo json_encode($cities);
        break;

    case 'barangays':
        $city_id = $_POST['city_id'];
        $query = "SELECT barangay_id, barangay_name FROM barangays WHERE city_id = '$city_id'";
        $result = mysqli_query($conn, $query);
        $barangays = mysqli_fetch_all($result, MYSQLI_ASSOC);
        echo json_encode($barangays);
        break;
}
?>