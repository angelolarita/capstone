<?php
include '../includes/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        if (!$pdo->inTransaction()) {
            $pdo->beginTransaction();
        }

        // Required fields validation (modify as needed)
        if (!isset($_POST['employed'])) {
            throw new Exception("Employment status is required.");
        }

        $stmt = $pdo->prepare("
            INSERT INTO employment_survey 
            (employed, reason_not_employed, other_reason_specify, employment_status, company_name, 
            business_type, other_business_type, work_place, first_job, job_search, break_duration, other_break_duration) 
            VALUES (:employed, :reason_not_employed, :other_reason_specify, :employment_status, :company_name, 
            :business_type, :other_business_type, :work_place, :first_job, :job_search, :break_duration, :other_break_duration)
        ");

        $success = $stmt->execute([
            ':employed' => $_POST['employed'] ?? null,
            ':reason_not_employed' => $_POST['reason_not_employed'] ?? null,
            ':other_reason_specify' => $_POST['other_reason_specify'] ?? null,
            ':employment_status' => $_POST['employment_status'] ?? null,
            ':company_name' => $_POST['company_name'] ?? null,
            ':business_type' => $_POST['business_type'] ?? null,
            ':other_business_type' => $_POST['other_business_type'] ?? null,
            ':work_place' => $_POST['work_place'] ?? null,
            ':first_job' => $_POST['first_job'] ?? null,
            ':job_search' => $_POST['job_search'] ?? null,
            ':break_duration' => $_POST['break_duration'] ?? null,
            ':other_break_duration' => $_POST['other_break_duration'] ?? null
        ]);

        if ($success) {
            if ($pdo->inTransaction()) {
                $pdo->commit();
            }
            echo "<script>
                    alert('Data submitted successfully!');
                    window.location.href = 'http://localhost/caps/landingpage.php';
                  </script>";
            exit();
        } else {
            throw new Exception("Failed to insert data.");
        }

    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log("Error: " . $e->getMessage()); // Log the error instead of displaying it
        echo "<script>
                alert('An error occurred while submitting the form.');
                window.history.back();
              </script>";
        exit();
    }
} else {
    echo "<script>
            alert('Invalid request method.');
            window.history.back();
          </script>";
    exit();
}
?>