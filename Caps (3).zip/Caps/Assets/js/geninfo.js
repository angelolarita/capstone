document.addEventListener("DOMContentLoaded", function () {
    function fetchData(url, data, callback) {
        fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams(data)
        })
        .then(response => response.json())
        .then(callback)
        .catch(error => console.error("Error:", error));
    }

    document.getElementById("region").addEventListener("change", function () {
        let regionId = this.value;
        let provinceSelect = document.getElementById("province");
        provinceSelect.innerHTML = '<option value="">Select Province</option>';
        document.getElementById("city").innerHTML = '<option value="">Select City</option>';
        document.getElementById("barangay").innerHTML = '<option value="">Select Barangay</option>';

        if (regionId) {
            fetchData("get_provinces.php", { region_id: regionId }, function (data) {
                data.forEach(province => {
                    provinceSelect.innerHTML += `<option value="${province.id}">${province.name}</option>`;
                });
            });
        }
    });

    document.getElementById("province").addEventListener("change", function () {
        let provinceId = this.value;
        let citySelect = document.getElementById("city");
        citySelect.innerHTML = '<option value="">Select City</option>';
        document.getElementById("barangay").innerHTML = '<option value="">Select Barangay</option>';

        if (provinceId) {
            fetchData("get_cities.php", { province_id: provinceId }, function (data) {
                data.forEach(city => {
                    citySelect.innerHTML += `<option value="${city.id}">${city.name}</option>`;
                });
            });
        }
    });

    document.getElementById("city").addEventListener("change", function () {
        let cityId = this.value;
        let barangaySelect = document.getElementById("barangay");
        barangaySelect.innerHTML = '<option value="">Select Barangay</option>';

        if (cityId) {
            fetchData("get_barangays.php", { city_id: cityId }, function (data) {
                data.forEach(barangay => {
                    barangaySelect.innerHTML += `<option value="${barangay.id}">${barangay.name}</option>`;
                });
            });
        }
    });
});
