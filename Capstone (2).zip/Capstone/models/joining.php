<?php

require_once __DIR__ . '/../core/Database.php';
require_once __DIR__ . '/../core/Udf.php';

class Joining {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function list() {
        $sql = "
            SELECT 
                g.id AS Graduate_ID,
                g.first_name AS first_name,
                g.middle_name AS middle_name,
                g.last_name AS Last_name,
                g.course AS Course,
                eb.school_name AS School,
                eb.degree AS Degree,
                e.employment_status AS Employment_Status,
                e.company_name AS Company,
                pe.exam_name AS Exam_Name,
                pe.passed AS Exam_Passed,
                t.training_name AS Training,
                t.date_completed AS Training_Completed,
                cr.reason AS Course_Reason,
                cr.category AS Course_Category
            FROM graduates g
            LEFT JOIN educational_background eb ON g.id = eb.graduate_id
            LEFT JOIN employment_survey ON g.id = e.alumni_id
            LEFT JOIN professional_exams pe ON g.id = pe.graduate_id
            LEFT JOIN trainings t ON g.id = t.graduate_id
            LEFT JOIN course_reasons cr ON g.course_id = cr.id;
        ";

        $stmt = $this->db->pdo->prepare($sql); 
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }  
}
?>