<?php
include_once '../CAPSTONE/templates/dash.php';

?>
<main>
    <!-- <h1 class="title">Dashboard</h1> -->
    <ul class="breadcrumbs">
        <li><a href="#">Home</a></li>
        <li class="divider">/</li>
        <li><a href="#" class="active">Dashboard</a></li>
    </ul>
    <div class="info-data">
        <div class="card">
            <div class="head">
                <div>
                    <img src="assets/img/tomb.png" alt="logo" id="data">"
                    <h2>Total of Submitted Form</h2>
                    <p></p>
                </div>
                <i class="bx bx-trending-up icon"></i>
            </div>

        </div>
        <div class="card">
            <div class="head">
                <div>
                    <img src="assets/img/cemetery.png" alt="logo" id="data">"
                    <h2>Total Of Employ</h2>
                    <p></p>
                </div>
                <i class="bx bx-trending-down icon down"></i>
            </div>

        </div>
        <div class="card">
            <div class="head">
                <div>
                    <img src="assets/img/cemetery.png" alt="logo" id="data">"
                    <h2>Total Of Not-Employ</h2>
                    <p></p>
                </div>
                <i class="bx bx-trending-down icon down"></i>
            </div>

        </div>
        <div class="card">
            <div class="head">
                <div>
                    <img src="assets/img/house.png" alt="logo" id="data">"
                    <h2> Total Course-Job
                        Misalignment </h2>
                    <p></p>
                </div>
                <i class="bx bx-trending-up icon"></i>
            </div>

        </div>
        <div class="card">
            <div class="head">
                <div>
                    <img src="assets/img/people.png" alt="logo" id="data">"
                    <h2>Reports Generated</h2>
                    <p></p>
                </div>
                <i class="bx bx-trending-up icon"></i>
            </div>

        </div>
    </div>