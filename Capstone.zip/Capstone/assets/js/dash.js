var ctx1 = document.getElementById('employmentChart').getContext('2d');
var employmentChart = new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: ['Employed', 'Unemployed', 'Seeking Employment'],
        datasets: [{
            label: 'Number of Alumni',
            data: [120, 45, 30], // Example data
            backgroundColor: ['#4CAF50', '#d9534f', '#f0ad4e'],
            borderColor: ['#4CAF50', '#d9534f', '#f0ad4e'],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

// Courses Taken by Alumni Chart
var ctx2 = document.getElementById('coursesChart').getContext('2d');
var coursesChart = new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: [
            'Bachelor of Technical Teacher Education',
            'Bachelor of Science in Computer Science',
            'Bachelor of Science in Information Technology',
            'Bachelor of Science in Office Administration',
            'Bachelor of Science in Entrepreneurship',
            'Bachelor of Science in Business Administration',
            'Bachelor of Science in Accounting Information System'
        ],
        datasets: [{
            data: [30, 45, 35, 50, 40, 60, 25], // Example data for each course
            backgroundColor: [
                '#FF5733', '#33FF57', '#3357FF', '#FF33A6', '#FFD433', '#33FFFB',
                '#FF9133' // Unique colors for each course
            ],
            borderColor: [
                '#FF5733', '#33FF57', '#3357FF', '#FF33A6', '#FFD433', '#33FFFB', '#FF9133'
            ],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true
    }
});