<?php
include_once '../CAPSTONE/templates/dash.php';

?>
<div87 class="content">
    <div class="card" style="margin-left: 10px;">
        <div class="card-header">
            <h2>Manage Alumni List</h2>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Course</th>
                            <th>Batch</th>
                            <th>Employment Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>John Doe</td>
                            <td>BSIT</td>
                            <td>2020</td>
                            <td>Employed</td>
                            <td>
                                <button class="btn btn-success btn-sm">View</button>
                                <button class="btn btn-primary btn-sm">Edit</button>
                                <button class="btn btn-danger btn-sm">Delete</button>
                            </td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Jane Smith</td>
                            <td>BSCS</td>
                            <td>2019</td>
                            <td>Unemployed</td>
                            <td>
                                <button class="btn btn-success btn-sm">View</button>
                                <button class="btn btn-primary btn-sm">Edit</button>
                                <button class="btn btn-danger btn-sm">Delete</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </div>