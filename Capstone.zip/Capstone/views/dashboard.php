<?php
include_once '../CAPSTONE/templates/dash.php';

?>
<!-- <h1 class="my-4">Dashboard</h1> -->
<div class="container custom-margin">
    <div class="row custom-margin">
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Total Alumni</div>
                <div class="card-body">
                    <h5>200</h5> <!-- Example number -->
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Active Users</div>
                <div class="card-body">
                    <h5>150</h5> <!-- Example number -->
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">New Registrations</div>
                <div class="card-body">
                    <h5>5</h5> <!-- Example number -->
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Reports Generated</div>
                <div class="card-body">
                    <h5>50</h5> <!-- Example number -->
                </div>
            </div>
        </div>
    </div>
</div>