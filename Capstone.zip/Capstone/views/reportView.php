<?php
include_once '../CAPSTONE/templates/dash.php';

?>

<div class="container custom-margin">
    <div class="row custom-margin">
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Total Alumni</div>
                <div class="card-body">
                    <h5>200</h5> <!-- Example number -->
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Active Users</div>
                <div class="card-body">
                    <h5>150</h5> <!-- Example number -->
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">New Registrations</div>
                <div class="card-body">
                    <h5>5</h5> <!-- Example number -->
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Reports Generated</div>
                <div class="card-body">
                    <h5>50</h5> <!-- Example number -->
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Alumni Employment Status Chart -->
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">Alumni Employment Status</div>
            <div class="card-body">
                <canvas id="employmentChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Courses Taken by Alumni Chart -->
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">Courses Taken by Alumni</div>
            <div class="card-body">
                <canvas id="coursesChart"></canvas>
            </div>
        </div>
    </div>
</div>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
<script>
// Alumni Employment Status Chart
var ctx1 = document.getElementById('employmentChart').getContext('2d');
var employmentChart = new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: ['Employed', 'Unemployed', 'Seeking Employment'],
        datasets: [{
            label: 'Number of Alumni',
            data: [120, 45, 30], // Example data
            backgroundColor: ['#4CAF50', '#d9534f', '#f0ad4e'],
            borderColor: ['#4CAF50', '#d9534f', '#f0ad4e'],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

// Courses Taken by Alumni Chart
var ctx2 = document.getElementById('coursesChart').getContext('2d');
var coursesChart = new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: [
            'Bachelor of Technical Teacher Education',
            'Bachelor of Science in Computer Science',
            'Bachelor of Science in Information Technology',
            'Bachelor of Science in Office Administration',
            'Bachelor of Science in Entrepreneurship',
            'Bachelor of Science in Business Administration',
            'Bachelor of Science in Accounting Information System'
        ],
        datasets: [{
            data: [30, 45, 35, 50, 40, 60, 25], // Example data for each course
            backgroundColor: [
                '#FF5733', '#33FF57', '#3357FF', '#FF33A6', '#FFD433', '#33FFFB',
                '#FF9133' // Unique colors for each course
            ],
            borderColor: [
                '#FF5733', '#33FF57', '#3357FF', '#FF33A6', '#FFD433', '#33FFFB', '#FF9133'
            ],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true
    }
});
</script>