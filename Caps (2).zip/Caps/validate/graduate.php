<?php
// Database connection
include '../includes/config.php';

// Fetch form data
$first_name = $_POST['first_name'];
$middle_name = $_POST['middle_name'];
$last_name = $_POST['last_name'];
$student_number = $_POST['student_number'];

// Check if the graduate exists
$sql = "SELECT * FROM graduates WHERE student_number = ? AND last_name = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$student_number, $last_name]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    // Redirect to survey form with an alert
    $query_params = http_build_query([
        'first_name' => $result['first_name'],
        'middle_name' => $result['middle_name'],
        'last_name' => $result['last_name'],
        'student_number' => $result['student_number'],
        'success' => 'true'
    ]);
    
    echo "<script>
            alert('Verification successful! Please proceed to the Graduate Tracer Survey.');
            window.location.href = '../geninfo.php?$query_params';
          </script>";
} else {
    echo "<script>
            alert('Verification failed. Graduate not found.');
            window.location.href='../index.php';
          </script>";
}
?>