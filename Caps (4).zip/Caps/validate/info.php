<?php
session_start();
if (!isset($_SESSION['alumni_data'])) {
    header("Location: http://localhost/Caps/validate/graduate.php");
    exit();
}

$alumniData = $_SESSION['alumni_data'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require '../includes/config.php';

    $permanentAddress = $_POST['address'] ?? '';
    $mobileNumber = $_POST['mobile'] ?? '';
    $civilStatus = $_POST['civilstatus'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $regionID = (int)($_POST['regions_id'] ?? 0);
    $provinceID = $_POST['provinces_id'] ?? '';
    $cityID = $_POST['municipalities_id'] ?? '';
    $barangayID = $_POST['barangays_id'] ?? '';

    function getNameById($pdo, $table, $idColumn, $idValue, $nameColumn) {
        if (!empty($idValue)) {
            $stmt = $pdo->prepare("SELECT $nameColumn FROM $table WHERE $idColumn = ?");
            $stmt->execute([$idValue]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result[$nameColumn] ?? '';
        }
        return '';
    }

    $regionName = getNameById($pdo, 'regions', 'id', $regionID, 'name');
    $provinceName = getNameById($pdo, 'provinces', 'province_id', $provinceID, 'name');
    $cityName = getNameById($pdo, 'municipalities', 'municipality_id', $cityID, 'name');
    $barangayName = getNameById($pdo, 'barangays', 'barangay_id', $barangayID, 'name');

    if (!empty($permanentAddress) && !empty($mobileNumber)) {
        $stmt = $pdo->prepare("UPDATE graduates SET
            permanent_address = :permanent_address,
            mobile_number = :mobile_number,
            civil_status = :civil_status,
            gender = :gender,
            regions = :regions,
            provinces = :provinces,
            municipalities = :municipalities,
            barangays = :barangays
            WHERE student_number = :student_number");

        $stmt->execute([
            ':permanent_address' => $permanentAddress,
            ':mobile_number' => $mobileNumber,
            ':civil_status' => $civilStatus,
            ':gender' => $gender,
            ':regions' => $regionName,
            ':provinces' => $provinceName,
            ':municipalities' => $cityName,
            ':barangays' => $barangayName,
            ':student_number' => $alumniData['student_number']
        ]);

        unset($_SESSION['alumni_data']);

        echo "<script>
                alert('Data submitted successfully!');
                window.location.href = 'http://localhost/caps/educationbackground.php';
              </script>";
        exit();
    } else {
        echo "<p style='color: red;'>Please fill in all required fields.</p>";
    }
}
?>